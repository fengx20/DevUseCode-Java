ecodeSDK.overwriteClassFnQueueMapSet('WeaBrowser',{
  fn: (Com, newProps, name)=>{
      const { type, tabs } = newProps;
      if (type != 1 && type != 17) return;
      if (!tabs || tabs.length == 0) return;

      tabs[1].selected = true;

      return newProps;
  }
});
