"use strict";

ecodeSDK.overwriteClassFnQueueMapSet('WeaBrowser', {
  fn: function fn(Com, newProps, name) {
    var type = newProps.type,
        tabs = newProps.tabs;
    if (type != 1 && type != 17) return;
    if (!tabs || tabs.length == 0) return;
    tabs[1].selected = true;
    return newProps;
  }
});