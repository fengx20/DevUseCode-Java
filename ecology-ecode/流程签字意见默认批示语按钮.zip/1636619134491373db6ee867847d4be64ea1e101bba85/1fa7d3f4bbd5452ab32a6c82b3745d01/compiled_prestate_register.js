"use strict";

var isTextRun = false;
var isSwLc = false;
var isSwLcHandle = false;
ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop', {
  //组件名
  fn: function fn(newProps) {
    //newProps代表组件参数
    var hash = window.location.hash;
    if (!hash.startsWith('#/main/workflow/req')) return;
    if (!WfForm) return;
    var baseInfo = WfForm.getBaseInfo(); // console.log(baseInfo);

    console.log(baseInfo.workflowid);
    console.log(baseInfo.nodeid); // 输入框填值

    var setRemark = function setRemark(remark) {
      // debugger;
      WfForm.setSignRemark(remark);

      if (window.CK_REF.odocFillRemarkCk) {
        window.CK_REF.odocFillRemarkCk.setState({
          'value': remark
        });
      }

      if (window.CK_REF.oDocRemark) {
        window.CK_REF.oDocRemark.setState({
          'value': remark
        }); // window.CK_REF.oDocRemark.state.value = remark
      }
    };

    if (baseInfo.workflowid == "42" || baseInfo.workflowid == "66" || baseInfo.workflowid == "62") {
      // 发文收文流程创建节点
      if (baseInfo.nodeid == "309" || baseInfo.nodeid == "162" || baseInfo.nodeid == "356") {
        WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
          onClick: function onClick() {
            setRemark("请审核。");
          }
        }, React.createElement("div", null, React.createElement("button", {
          class: "ant-btn ant-btn-primary"
        }, React.createElement("span", {
          class: "wea-cbi-icon icon-coms-Advice"
        }), " ", React.createElement("span", {
          class: "remark-padding"
        }, "\u8BF7\u5BA1\u6838")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
      } // 发文流程三核节点、阳光政务节点
      else if (baseInfo.nodeid == "314" || baseInfo.nodeid == "168" || baseInfo.nodeid == "361" || baseInfo.nodeid == "367" || baseInfo.nodeid == "246" || baseInfo.nodeid == "320") {
          WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
            onClick: function onClick() {
              setRemark("请审核。");
            }
          }, React.createElement("div", null, React.createElement("button", {
            class: "ant-btn ant-btn-primary"
          }, React.createElement("span", {
            class: "wea-cbi-icon icon-coms-Advice"
          }), " ", React.createElement("span", {
            class: "remark-padding"
          }, "\u8BF7\u5BA1\u6838")))), React.createElement("div", {
            onClick: function onClick() {
              setRemark("同意。");
            }
          }, React.createElement("div", null, React.createElement("button", {
            class: "ant-btn ant-btn-primary"
          }, React.createElement("span", {
            class: "wea-cbi-icon icon-coms-Advice"
          }), " ", React.createElement("span", {
            class: "remark-padding"
          }, "\u540C\u610F")))), React.createElement("div", {
            onClick: function onClick() {
              setRemark("请签发。");
            }
          }, React.createElement("div", null, React.createElement("button", {
            class: "ant-btn ant-btn-primary"
          }, React.createElement("span", {
            class: "wea-cbi-icon icon-coms-Advice"
          }), " ", React.createElement("span", {
            class: "remark-padding"
          }, "\u8BF7\u7B7E\u53D1")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
        } // 发文流程分派打印任务节点
        else if (baseInfo.nodeid == "316" || baseInfo.nodeid == "170" || baseInfo.nodeid == "363") {
            WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
              onClick: function onClick() {
                setRemark("同意。");
              }
            }, React.createElement("div", null, React.createElement("button", {
              class: "ant-btn ant-btn-primary"
            }, React.createElement("span", {
              class: "wea-cbi-icon icon-coms-Advice"
            }), " ", React.createElement("span", {
              class: "remark-padding"
            }, "\u540C\u610F")))), React.createElement("div", {
              onClick: function onClick() {
                setRemark("请排版。");
              }
            }, React.createElement("div", null, React.createElement("button", {
              class: "ant-btn ant-btn-primary"
            }, React.createElement("span", {
              class: "wea-cbi-icon icon-coms-Advice"
            }), " ", React.createElement("span", {
              class: "remark-padding"
            }, "\u8BF7\u6392\u7248")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
          } // 发文流程排版节点
          else if (baseInfo.nodeid == "317" || baseInfo.nodeid == "171" || baseInfo.nodeid == "364") {
              WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
                onClick: function onClick() {
                  setRemark("同意。");
                }
              }, React.createElement("div", null, React.createElement("button", {
                class: "ant-btn ant-btn-primary"
              }, React.createElement("span", {
                class: "wea-cbi-icon icon-coms-Advice"
              }), " ", React.createElement("span", {
                class: "remark-padding"
              }, "\u540C\u610F")))), React.createElement("div", {
                onClick: function onClick() {
                  setRemark("请校对。");
                }
              }, React.createElement("div", null, React.createElement("button", {
                class: "ant-btn ant-btn-primary"
              }, React.createElement("span", {
                class: "wea-cbi-icon icon-coms-Advice"
              }), " ", React.createElement("span", {
                class: "remark-padding"
              }, "\u8BF7\u6821\u5BF9")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
            } // 其他节点
            else {
                WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
                  onClick: function onClick() {
                    setRemark("请审核。");
                  }
                }, React.createElement("div", null, React.createElement("button", {
                  class: "ant-btn ant-btn-primary"
                }, React.createElement("span", {
                  class: "wea-cbi-icon icon-coms-Advice"
                }), " ", React.createElement("span", {
                  class: "remark-padding"
                }, "\u8BF7\u5BA1\u6838")))), React.createElement("div", {
                  onClick: function onClick() {
                    setRemark("同意。");
                  }
                }, React.createElement("div", null, React.createElement("button", {
                  class: "ant-btn ant-btn-primary"
                }, React.createElement("span", {
                  class: "wea-cbi-icon icon-coms-Advice"
                }), " ", React.createElement("span", {
                  class: "remark-padding"
                }, "\u540C\u610F")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
              } // WfForm.appendSignEditorBottomBar([
      //   React.createElement("div",{onClick: () => {setRemark("请审核。")}}, <div><span class="wea-cbi-icon icon-coms-Advice"></span><span class="remark-padding">请审核</span></div>),
      //   React.createElement("div",{onClick: () => {setRemark("同意。")}}, <div><span class="wea-cbi-icon icon-coms-Advice"></span><span class="remark-padding">同意</span></div>),
      //   React.createElement("div",{onClick: () => {setRemark("请签发。")}}, <div><span class="wea-cbi-icon icon-coms-Advice"></span><span class="remark-padding">请签发</span></div>),
      //   React.createElement("div",{onClick: () => {setRemark("请排版。")}}, <div><span class="wea-cbi-icon icon-coms-Advice"></span><span class="remark-padding">请排版</span></div>),
      //   React.createElement("div",{onClick: () => {setRemark("请校对。")}}, <div><span class="wea-cbi-icon icon-coms-Advice"></span><span class="remark-padding">请校对</span></div>),
      //   React.createElement("div",{onClick: () => {setRemark("请盖章。")}}, <div><span class="wea-cbi-icon icon-coms-Advice"></span><span class="remark-padding">请盖章</span></div>)
      //   // React.createElement("div",{onClick: () => {
      //   //   var account = window.localStorage['theme-account'];
      //   //   setRemark(JSON.parse(account).username);
      //   // }}, <div><span class="wea-cbi-icon icon-coms-Advice"></span><span class="remark-padding">仅签名</span></div>)
      // ]);

    } else if (baseInfo.workflowid == "64" || baseInfo.workflowid == "65") {
      // 收文流程创建节点
      if (baseInfo.nodeid == "337" || baseInfo.nodeid == "325") {
        WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
          onClick: function onClick() {
            setRemark("请审核。");
          }
        }, React.createElement("div", null, React.createElement("button", {
          class: "ant-btn ant-btn-primary"
        }, React.createElement("span", {
          class: "wea-cbi-icon icon-coms-Advice"
        }), " ", React.createElement("span", {
          class: "remark-padding"
        }, "\u8BF7\u5BA1\u6838")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
      } // 收文流程其他节点
      else {
          WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
            onClick: function onClick() {
              setRemark("请审核。");
            }
          }, React.createElement("div", null, React.createElement("button", {
            class: "ant-btn ant-btn-primary"
          }, React.createElement("span", {
            class: "wea-cbi-icon icon-coms-Advice"
          }), " ", React.createElement("span", {
            class: "remark-padding"
          }, "\u8BF7\u5BA1\u6838")))), React.createElement("div", {
            onClick: function onClick() {
              setRemark("请办理。");
            }
          }, React.createElement("div", null, React.createElement("button", {
            class: "ant-btn ant-btn-primary"
          }, React.createElement("span", {
            class: "wea-cbi-icon icon-coms-Advice"
          }), " ", React.createElement("span", {
            class: "remark-padding"
          }, "\u8BF7\u529E\u7406")))), React.createElement("div", {
            onClick: function onClick() {
              setRemark("已办理。");
            }
          }, React.createElement("div", null, React.createElement("button", {
            class: "ant-btn ant-btn-primary"
          }, React.createElement("span", {
            class: "wea-cbi-icon icon-coms-Advice"
          }), " ", React.createElement("span", {
            class: "remark-padding"
          }, "\u5DF2\u529E\u7406")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
        }
    } // 信息发布模块所有流程


    if (baseInfo.workflowid == "52" || baseInfo.workflowid == "53" || baseInfo.workflowid == "68" || baseInfo.workflowid == "67" || baseInfo.workflowid == "59" || baseInfo.workflowid == "54" || baseInfo.workflowid == "48") {
      WfForm.appendSignEditorBottomBar([React.createElement("div", null, '常用意见:'), React.createElement("div", {
        onClick: function onClick() {
          setRemark("请审核。");
        }
      }, React.createElement("div", null, React.createElement("button", {
        class: "ant-btn ant-btn-primary"
      }, React.createElement("span", {
        class: "wea-cbi-icon icon-coms-Advice"
      }), " ", React.createElement("span", {
        class: "remark-padding"
      }, "\u8BF7\u5BA1\u6838")))), React.createElement("div", {
        onClick: function onClick() {
          setRemark("已审核。");
        }
      }, React.createElement("div", null, React.createElement("button", {
        class: "ant-btn ant-btn-primary"
      }, React.createElement("span", {
        class: "wea-cbi-icon icon-coms-Advice"
      }), " ", React.createElement("span", {
        class: "remark-padding"
      }, "\u5DF2\u5BA1\u6838")))), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null)), React.createElement("div", React.createElement("div", null))]);
    }

    return newProps;
  },
  order: 13,
  //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
  desc: '添加签字意见按钮'
}); // ecodeSDK.overwritePropsFnQueueMapSet('WeaDialog',{ //组件名
//     fn:(newProps,name)=>{ //newProps代表组件参数
//       let hash = window.location.hash;
//       if(!hash.startsWith('#/main/workflow/req')) return;
//       if(newProps.title == undefined) return;
//       if(typeof newProps.title != "string") return; 
//       if($('#forwardremark > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1) > div > div > span.remark-padding').length > 0) {
//         $('#forwardremark > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//         $('#forwardremark > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//         $('#forwardremark > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//         $('#forwardremark > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//       }
//       if($('#widthEdit > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1) > div > div > span.remark-padding').length > 0) {
//         $('#widthEdit > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//         $('#widthEdit > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//         $('#widthEdit > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//         $('#widthEdit > div > div > div.wea-rich-text-toolbar-bottom > span:nth-child(1)').remove();
//       }
//       return newProps; //修改之后返回数据
//     },
//     order:0, //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
//     desc:'在这里写此复写的作用，在调试的时候方便查找'
// });
// ecodeSDK.overwriteMobilePropsFnQueueMapSet('TabPage',{ //组件名
//     fn:(newProps)=>{ //newProps代表组件参数
//         let hash = window.location.hash;
//         if(!hash.startsWith('#/req')) return;
//         if(!WfForm) return;
//         var baseInfo = WfForm.getBaseInfo();
//         if(!baseInfo || !baseInfo.workflowid || baseInfo.workflowid == "") return;
//         // var flag = isGwlc(baseInfo.workflowid);
//         // if(!flag) return;
//         var isSw = false;
//         // //如果是收文流程不显示
//         // if(isSwLcHandle) {
//         //   if(isSwLc) {
//         //     isSw = true;
//         //   };
//         // } else {
//         //   if(isGwlcType(baseInfo.workflowid)) {
//         //     isSw = true;
//         //   };
//         // }
//         //进行位置判断
//         setHtml(isSw);
//         return newProps;
//     },
//     order:1, //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
//     desc:'在这里写此复写的作用，在调试的时候方便查找'
// });
// function setHtml(isSw) {
//   function setRemark(remark){
//     WfForm.setSignRemark(remark);
//   }
//   var int = setInterval(function(){
//     if($('#root > div > div > div.wf-req-main > div.wf-req-bottom > div > div.wf-signView-panel > div.wf-sign-input-more-info > div').length > 0) {
//       window.clearInterval(int);
//       var $Div = $('#root > div > div > div.wf-req-main > div.wf-req-bottom > div > div.wf-signView-panel > div.wf-sign-input-more-info > div');
//       if($('#tj').length <= 0) {
//         $Div.append('<div class="more-info-col remark_bt" id="tj"><div class="item-icon sign-icon"><div><div><svg class="am-icon am-icon-sign am-icon-md"><use xlink:href="#sign"></use></svg></div></div></div><div class="custom-title" >同意</div></div>');
//         if(!isSw){
//           $Div.append('<div class="more-info-col remark_bt"><div class="item-icon sign-icon"><div><div><svg class="am-icon am-icon-sign am-icon-md"><use xlink:href="#sign"></use></svg></div></div></div><div class="custom-title" >不同意</div></div>');
//         }
//         $Div.append('<div class="more-info-col remark_bt"><div class="item-icon sign-icon"><div><div><svg class="am-icon am-icon-sign am-icon-md"><use xlink:href="#sign"></use></svg></div></div></div><div class="custom-title" >已阅</div></div>');
//         // $Div.append('<div class="more-info-col remark_bt"><div class="item-icon sign-icon"><div><div><svg class="am-icon am-icon-sign am-icon-md"><use xlink:href="#sign"></use></svg></div></div></div><div class="custom-title" >拟同意</div></div>');
//         $Div.append('<div class="more-info-col remark_bt"><div class="item-icon sign-icon"><div><div><svg class="am-icon am-icon-sign am-icon-md"><use xlink:href="#sign"></use></svg></div></div></div><div class="custom-title" >仅签名</div></div>');
//         $('.remark_bt').on("click",function(){
//           var text = $(this).text();
//           if (text == '仅签名') {
//             var account = window.WeaverMobile.Tools.ls.getStr("theme-account");
//             text = JSON.parse(account).username;
//             // alert(window.localStorage.baseUserName);
//             // text = window.localStorage.baseUserName;
//           }
//           setRemark(text);
//         });
//       }
//     }
//   }, 50);
// }