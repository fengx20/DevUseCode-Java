"use strict";

var enable = true;
ecodeSDK.overwritePropsFnQueueMapSet('WeaTab', {
  //组件名
  fn: function fn(newProps) {
    //newProps代表组件参数
    // console.log(newProps);
    var hash = window.location.hash;
    if (!enable) return;
    if (hash.indexOf('#/main/workflow/req') < 0) return; //判断页面地址

    if (!ecCom.WeaTools.Base64) return; //完整组件库加载完成

    if (!WfForm) return; //表单sdk加载完成

    var baseInfo = WfForm.getBaseInfo(); // console.log("ccc："+baseInfo);

    var workflowid = baseInfo.workflowid;
    var nodeid = baseInfo.nodeid;
    var formid = baseInfo.formid;
    var requestid = baseInfo.requestid; //数组操作，引入组件，可以放入任意位置，数组元素的类型必须匹配，修改对应数据必须判断下标
    // const {Button} = antd;
    // var index =-1;
    //信息发布节点

    if (workflowid == "42" || workflowid == "66" || workflowid == "64" || workflowid == "62" || workflowid == "65" || workflowid == "47") {
      console.log(newProps);
      var datas = newProps.datas || []; // 获取当前签字意见页签数据
      //删除与我相关

      var item = newProps.datas;
      var newitem = item.filter(function (item) {
        return item.title != '与我相关';
      });
      newProps.datas = newitem; // newProps.datas = [...datas, {
      //   title: "新页签", key: "3", com: (<div>自定义新页签内容</div>) // com为自定义的内容
      // }];
      // if (newProps.selectedKey === '3') { // 定义自定义tab页样式类
      //   newProps.className = 'ecode-signInfo';
      //   newProps.hasDropMenu = false;
      // } else {
      //   newProps.className = '';
      //   newProps.hasDropMenu = true;
      // }
      // console.log("测试11111111111111111111");
      //   if(newProps.buttons){
      //   var arr = newProps.buttons;
      //   for(var i=0;i<arr.length;i++){
      //     if(arr[i].props.title=='保存'){
      //       index=i;
      //       newProps.buttons.splice(i, 1);
      //       break;
      //     }
      //   }
      // }
      // if(index==-1) return;
      // newProps.buttons[index].props.onClick = () =>{
      //     alert("请到预采用中提交流程");
      // }  
      //删除退回按钮
      // let item = newProps.buttons;
      // let newitem = item.filter(item=>{
      //   return item.props.title!='退回'
      // })
      //   newProps.buttons = newitem;
    }

    return newProps; //修改之后返回数据
  },
  order: 1,
  //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
  desc: ''
});