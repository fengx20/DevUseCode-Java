    let exist = false;
    // ecodeSDK.overwritePropsFnQueueMapSet('Tabs', {
    //     fn: (newProps) => { //newProps代表组件参数
    //         const {hash} = window.location;
    //         if (!hash.startsWith('#/main/workflow/req')) return;
    //         const baseInfo = WfForm.getBaseInfo();
    //         //判断流程id
    //         var flowid = baseInfo.workflowid;
    //         if(!(flowid==66 || flowid==42 || flowid ==47)) return;

    //         //切换正文点击编辑按钮
    //         // if(newProps.defaultActiveKey=="odoc"){
    //         //   $(".wea-new-top-req-title>.ant-col-xs-18>div>span").each(function(){
    //         //     if($(this).text().indexOf("编 辑")!=-1){
    //         //        $(this).children().click();
    //         //     }
    //         //   })
    //         // }
        
    //         // var innwens = window.setInterval(function () {
    //         //     if ($(".wf-req-top-button").length > 0 && !exist) {
    //         //         exist = true;
    //         //         window.clearInterval(innwens);
    //         //         const acParams = {
    //         //             appId: '${appId}',
    //         //             name: 'proofblock', //模块名
    //         //             isPage: false, //是否是路由页面
    //         //             noCss: true //是否禁止单独加载css，通常为了减少css数量，css默认前置加载
    //         //         }
    //         //         var Com = ecodeSDK.getAsyncCom(acParams);
    //         //         $(".wf-req-top-button:first").parent().parent().before("<span id='proofid' style='display: inline-block; line-height: 28px; vertical-align: middle; margin-left: 10px;'>测试</span>");
    //         //         ReactDOM.render(Com, document.getElementById('proofid'))   
    //         //     }
    //         // }, 1000);
    //     },
    //     order: 1, //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
    //     desc: '在这里写此复写的作用，在调试的时候方便查找'
    // });


 ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop',{ //组件名
    fn:(newProps)=>{ //newProps代表组件参数
        const {hash} = window.location;
        if (!hash.startsWith('#/main/workflow/req')) return;
        const baseInfo = WfForm.getBaseInfo();
        //判断流程id
        var flowid = baseInfo.workflowid;
        var requestid = baseInfo.requestid;
        // console.log("lllc："+requestid);
        // console.log(newProps);
       if(!(flowid==66 || flowid==42 || flowid ==62)) return;
        if(newProps.buttons){
          var arr = newProps.buttons;
          for(var i=0;i<arr.length;i++){
            if(arr[i].props.title=='提交' || arr[i].props.title=='签发'){
              // newProps = arr[i].props; 
              // break;
              var oldclick = arr[i].props.onClick;
              arr[i].props.onClick = ()=>{

                jQuery.ajax({
                  type:"GET",
                  url:"/r_rz_zdbg/api/subworkflowapi/subarchivehalf",
                  data:{mainrequestid:requestid},
                  async:false,
                  dataType:"json",
                  success:function(data){
                    console.log(data);
                    flag = data.result;
                      if(flag=="success"){
                          oldclick();
                      }else{ 
                        // antd.message.info("1111");
                        WfForm.showMessage("已完成会签处室未达到50%，请稍后再提交");
                        // alert("子流程归档未超过50%，暂时无法提交");
                          // WfForm.showConfirm("未进行内容文本校对，是否提交？", function(){
                               
                          // });
                      }
                  }
                });
              }
              break; 
            }
          }
        }
        // console.log();
//         var oldclick = newProps.onClick;
//         newProps.onClick = ()=>{
// //             ajax....{
// //     if(满足){
// // oldonclick();
// // }
// // }
//           var a = false;
//           if(a){
//             oldclick();
//           }else{
//             alert("不允许提交");
//           }

//       //   var fn1 = function (callbackFn){
//       //     //做fn1需要做的逻辑
//       //     oldclick();
//       //     if (callbackFn) callbackFn();
//       //   }
//       //   var fn2 = function (callbackFn){
//       //     //做fn2需要做的逻辑
//       //     WfForm.doRightBtnEvent("BTN_WFSAVE");     //触发保存
//       //     if (callbackFn) callbackFn();
//       //   }
//       // //如果fn2需要在fn1执行完后，再执行，可以：
//       // fn1(fn2);
//         }
        return newProps;      
    },
    order:1, //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
    desc:'在这里写此复写的作用，在调试的时候方便查找'
});

    