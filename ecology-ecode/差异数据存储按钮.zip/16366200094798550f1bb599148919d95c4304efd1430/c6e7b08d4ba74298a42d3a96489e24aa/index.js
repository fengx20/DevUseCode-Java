const {Button, Modal, Spin, Alert} = antd;
const {WeaDialog, WeaTools} = ecCom;
const { observer, inject } = mobxReact;

class SaveData extends React.Component {
  constructor(props) { //初始化，固定语法
    super(props);
    // this.state = {
    //   title: "触发弹窗",
    //   visible: false
    // };
  }
  componentDidMount() {
    ecodeSDK.setCom('${appId}','SaveData',this);
  }
  componentWillUnmount() {
    ecodeSDK.setCom('${appId}','SaveData',null);
  }
  // triggerModal(b) {
  //   this.setState({
  //     visible:b
  //   });
  // }
  showConfirm() {
    Modal.confirm({
      title: "差异数据存储",
      content: "是否存储近四个月差异数据？",
      onOk() {
        // ReactDOM.render(
//   <Spin tip="正在读取数据...">
//     <Alert message="消息提示的文案"
//       description="消息提示的辅助性文字介绍消息提示的辅助性文字介绍消息提示的辅助性文字介绍"
//       type="info"
//     />
//   </Spin>
// , mountNode);

        ecCom.WeaTools.callApi('/api/closedata/saveandcaldiff', 'GET').then(
          function(data){
            if(data.result == "success"){
              const modal = Modal.success({
                title: '存储差异数据',
                content: '正在存储，请稍后查看',
              });
              setTimeout(() => modal.destroy(), 5000);
            }
            // console.log(data.result);
          }
        )
      },
      onCancel() {
        console.log("取消存储");
      }
    });
  }
  render() {
    let buttons = [
      <Button type="primary" onClick={() => this.setState({ visible: false })}>
        确定
      </Button>,
      <Button type="ghost" onClick={() => this.setState({ visible: false })}>
        取消
      </Button>
    ];
    //const { title, visible } = this.state;
    return (
      ""
    );
  }
}

//发布模块
ecodeSDK.setCom('${appId}','SaveData',SaveData);

