"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Button = _antd.Button,
    Modal = _antd.Modal,
    Spin = _antd.Spin,
    Alert = _antd.Alert;
var _ecCom = ecCom,
    WeaDialog = _ecCom.WeaDialog,
    WeaTools = _ecCom.WeaTools;
var _mobxReact = mobxReact,
    observer = _mobxReact.observer,
    inject = _mobxReact.inject;

var SaveData =
/*#__PURE__*/
function (_React$Component) {
  _inherits(SaveData, _React$Component);

  function SaveData(props) {
    _classCallCheck(this, SaveData);

    //初始化，固定语法
    return _possibleConstructorReturn(this, _getPrototypeOf(SaveData).call(this, props)); // this.state = {
    //   title: "触发弹窗",
    //   visible: false
    // };
  }

  _createClass(SaveData, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      ecodeSDK.setCom('${appId}', 'SaveData', this);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      ecodeSDK.setCom('${appId}', 'SaveData', null);
    } // triggerModal(b) {
    //   this.setState({
    //     visible:b
    //   });
    // }

  }, {
    key: "showConfirm",
    value: function showConfirm() {
      Modal.confirm({
        title: "差异数据存储",
        content: "是否存储近四个月差异数据？",
        onOk: function onOk() {
          // ReactDOM.render(
          //   <Spin tip="正在读取数据...">
          //     <Alert message="消息提示的文案"
          //       description="消息提示的辅助性文字介绍消息提示的辅助性文字介绍消息提示的辅助性文字介绍"
          //       type="info"
          //     />
          //   </Spin>
          // , mountNode);
          ecCom.WeaTools.callApi('/api/closedata/saveandcaldiff', 'GET').then(function (data) {
            if (data.result == "success") {
              var modal = Modal.success({
                title: '存储差异数据',
                content: '正在存储，请稍后查看'
              });
              setTimeout(function () {
                return modal.destroy();
              }, 5000);
            } // console.log(data.result);

          });
        },
        onCancel: function onCancel() {
          console.log("取消存储");
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this = this;

      var buttons = [React.createElement(Button, {
        type: "primary",
        onClick: function onClick() {
          return _this.setState({
            visible: false
          });
        }
      }, "\u786E\u5B9A"), React.createElement(Button, {
        type: "ghost",
        onClick: function onClick() {
          return _this.setState({
            visible: false
          });
        }
      }, "\u53D6\u6D88")]; //const { title, visible } = this.state;

      return "";
    }
  }]);

  return SaveData;
}(React.Component); //发布模块


ecodeSDK.setCom('${appId}', 'SaveData', SaveData);
