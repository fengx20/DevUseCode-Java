let enable = true;

const openDialog = ()=>{
    let instance = ecodeSDK.getCom('${appId}','SaveData');
    instance && instance.showConfirm();
}

ecodeSDK.overwritePropsFnQueueMapSet('WeaTop',{
    fn:(newProps)=>{
        if(!enable) return;
        if(!ecodeSDK.checkLPath('/wui/index.html#/main/cube/search?customid=57')) return ;
        if((ModeForm.getCurrentUserInfo().userid != 1)) return ;
        // console.log('WeaTop:',newProps);
        if(newProps.children) {
            const acParams = {
                appId:'${appId}',
                name:'SaveData', //模块名称
                isPage:false, //是否是路由页面
                noCss:true //是否禁止单独加载css，通常为了减少css数量，css默认前置加载
            }
            const Com = ecodeSDK.getAsyncCom(acParams);
            if(newProps.children instanceof Array) {
                newProps.children.push(Com);
            }else {
                newProps.children = [newProps.children,Com]
            }
            const {Button} = antd;
            if(newProps.buttons) { //增加顶部显示出来的按钮
                newProps.buttons[1] = newProps.buttons[0];
                newProps.buttons[0] = (<Button type="ghost" onClick={()=>{openDialog()}} >存储差异数据</Button>);
            }
            return newProps;
        }
        
    }
});

/*
版本要求：kb1906+
外部任意位置调用弹窗：
let instance = ecodeSDK.getCom('d1bc70d33479441d99806d8b4f1f0a67','NewCubeButtonComInstance');
instance && instance.triggerModal(true);


*/

