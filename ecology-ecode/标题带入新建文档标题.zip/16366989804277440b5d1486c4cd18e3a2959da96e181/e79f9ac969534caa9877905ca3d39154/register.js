//需要标题赋值跳转后文档的标题的流程，流程直接通过,隔开即可
//通知;厅公告;党风廉政;厅领导政务活动;处公告;外网（含OA新闻）;
var createWorkflows = [48,52,53,68,86,59];
ecodeSDK.overwritePropsFnQueueMapSet('WeaBrowser',{ //组件名
    fn:(newProps)=>{ //newProps代表组件参数
        const {hash} = window.location;
        if(!hash.startsWith('#/main/workflow/req')) return ;
        var baseInfo = WfForm.getBaseInfo();
        if(createWorkflows.length > 0 && $.inArray((baseInfo.workflowid), createWorkflows) < 0)return;
        if (newProps.type == 37) {
          // console.log('WeaBrowser:',newProps); //在这里输出日志，如果成功输出代表组件成功定位
          var oldonclick=newProps.addOnClick;
          newProps.addOnClick=()=>{
            var fieldidbt = WfForm.convertFieldNameToId("bt");
            fieldbtvalue = WfForm.getFieldValue(fieldidbt);
            localStorage.setItem('bt'+baseInfo.workflowid,fieldbtvalue);
            oldonclick();
          }
        }
    },
    order:1, //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
    desc:'在这里写此复写的作用，在调试的时候方便查找'
});



// var flag=false;
// var yt=undefined;
// ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop',{ //组件名
//     fn:(newProps)=>{ //newProps代表组件参数
//         const {hash} = window.location;
//         if(!hash.startsWith('#/main/document/edit')) return ;
//         // console.log('WeaReqTop:',newProps); //在这里输出日志，如果成功输出代表组件成功定位
//         if(window.location.href.indexOf("&moudleFrom=workflow&workflowid=")==-1) return;
//         console.log('WeaReqTop:',newProps); //在这里输出日志，如果成功输出代表组件成功定位
//         var hsh=window.location.search.split("&")[3].split("?")[0];
//         var workid=hsh.split("=");
//         var fliedbt=localStorage.getItem("bt"+workid[1]+"");
//         newProps.title.props.children[0].props.value=fliedbt;
//         newProps.title.props.children[0].props.viewAttr="2"
//         yt=newProps.title.props.children[0].props.onChange;
//         // newProps.title.props.children[0].props.onChange=()=>{
//           // debugger;
          
//         // }
//         if(!flag){
//           var omm=window.setInterval(function(){
//             if($(".wea-input-normal .ant-input-wrapper .ant-input").length>0){
//               flag=true;
//               window.clearInterval(omm);
//               $(".wea-input-normal .ant-input-wrapper .ant-input").each(function(){
//                 if($(this).val()==fliedbt){
//                   // debugger;
//                   // $(this).focus();
//                   // var text=$(this).val();
//                   // $(this).val("");
//                   // $(this).val(text+"1");
//                   yt();
//                 }
//               })
//             }
//           },500)
//         }        
//     },
//     order:1, //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
//     desc:'在这里写此复写的作用，在调试的时候方便查找'
// });


ecodeSDK.overwritePropsFnQueueMapSet('WeaInput',{ //组件名
    fn:(newProps)=>{ //newProps代表组件参数
        const {hash} = window.location;
        if(!hash.startsWith('#/main/document/edit')) return ;
        if(window.location.href.indexOf("&moudleFrom=workflow")==-1) return;
        if(newProps.placeholder!="文档标题")return;
        console.log("WeaInput",newProps)
        var workflowid = getQueryStringByName('workflowid');
        var fliedbt=localStorage.getItem("bt"+workflowid);

        newProps.value=fliedbt;
        var docw=newProps.onChange;
        window.newdoc=docw;
        window.newdoc(fliedbt);
        // if(fliedbt!=""){
        //   newProps.viewAttr = 2;
        // }
        
        // console.log(newProps);
        return newProps;
    },
    order:1, //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
    desc:'在这里写此复写的作用，在调试的时候方便查找'
});


function getQueryStringByName(name) {
  var result = window.location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));
  if(result == null || result.length < 1){
        result = window.location.hash.match(new RegExp("[\?\&]" + name+ "=([^\&]+)","i"));
    }
    if(result == null || result.length < 1){
        return "";
    }
    return result[1];
}