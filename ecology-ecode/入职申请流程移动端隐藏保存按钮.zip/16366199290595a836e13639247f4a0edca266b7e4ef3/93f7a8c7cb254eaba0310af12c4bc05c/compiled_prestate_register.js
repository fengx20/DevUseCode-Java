"use strict";

var enable = true;
ecodeSDK.overwriteMobilePropsFnQueueMapSet('Flex', {
  //组件名
  fn: function fn(newProps) {
    //newProps代表组件参数
    var hash = window.location.hash;
    if (!enable) return;
    if (!hash.startsWith('#/req?iscreate=1&workflowid=53')) return; //判断页面地址

    console.log(newProps); // console.log(newProps.children);
    //数组操作，引入组件，可以放入任意位置，数组元素的类型必须匹配，修改对应数据必须判断下标

    if (newProps.children) {
      var arr = newProps.children;

      for (var i = 0; i < arr.length; i++) {
        if (newProps.className == 'wf-bottomOperate-container') {
          if (arr[i].key == '1') {
            newProps.children.splice(i, 1);
          }

          if (arr[i].key == '2') {
            newProps.children.splice(i, 1);
            break;
          }
        }
      }
    }

    return newProps; //修改之后返回数据
  },
  order: 1,
  //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
  desc: '隐藏保存按钮'
});