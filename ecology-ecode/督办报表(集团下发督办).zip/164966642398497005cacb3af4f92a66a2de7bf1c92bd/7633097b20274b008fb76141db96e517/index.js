const { WeaEchart,WeaRangePicker ,WeaBrowser } = ecCom;

const defaultBrowserParams = {
  icon: "icon-toolbar-Organization-list",
  iconBgcolor: "#b32e37",
  inputStyle: { width: 250 },
  maxBrowerHeight:40,
  // ecId: "WeaBrowser@0t62u8",
  hasAdvanceSerach: true,
  pageSize: 30,
  selectedAllMaxLength: 500,
  displaySearchAdInBar: true,
  onBeforeFocusCheck: success => success(),
  placeholder: "选择承办部门",
  title:'部门列表'
};

class dubanbaobiao extends React.Component {

 constructor(props) {
     
    super(props);
    this.state = {
      // sum :'0',
      // todo: '0',
      // xiaohao:'0',
      // delay:'0',
      // cancel:'0',
      date: "",
      browserValue: "",
      option: {},
      // flag: false
    };
  }



  //   // 初始化渲染页面
  componentDidMount() { 
    let data = this.getdata("","","");
    console.log(data);
    // debugger;
    this.setState({
       option:data
    })
  }


  initialize = ()=>{
      let that = this;
      const {browserValue, date} = this.state;

      
    setTimeout(function(){
        let startTime = $("input[placeholder$='开始日期']").attr("value");
        let endTime = $("input[placeholder$='结束日期']").attr("value");
        let cbbmdw = $("input[ecid$='undefined_WrappedComponent@i9q2c5_Component@iiw91q_input@jc79en']").attr("value");
        console.log(cbbmdw);
        console.log(startTime);
        console.log(endTime);
        let data = that.getdata(cbbmdw,startTime,endTime);
        // debugger;
        console.log(data);
        // this.setState({option:data,flag: true});
                that.setState({option:data});
                that.refs.chart.clear();
                that.forceUpdate();
                that.refs.chart.paint();
    },10)

  }



       getdata= (cbbmdw,startTime,endTime)=>{
        var sum = "0";
				var todo = "0";
				var xiaohao = "0";
				var delay = "0";
				var cancel = "0";
				jQuery.ajax({
					type:"GET",
					url:"/api/gtjt/OverseeReportAction/getDuBanJt",
					data:{"cbbmdw":cbbmdw,"startTime":startTime,"endTime":endTime},
					async:false,
					dataType:"json",
					success:function(data){
					sum = data.sumNum;
					todo = data.todoNum;
					xiaohao = data.xiaohaoNum;
					delay = data.delayNum;
					cancel = data.cancelNum;
				     }
             	});
              //  console.log(sum);
              //  console.log(todo);
              //  console.log(xiaohao);
              //  console.log(delay);
              //  console.log(cancel);
              var newData ={
    xAxis: {
        type: 'category',
        data: ["督办总数", "督办承办", "督办销号", "督办延期", "督办取消"]
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        data: [ {
            value: sum,
            itemStyle: {
                color: '#4a94ff'
            }
        }, {
            value: todo,
            itemStyle: {
                color: '#894ae9'
            }
        },  {
            value: xiaohao,
            itemStyle: {
                color: '#159dd1'
            }
        },  {
            value: delay,
            itemStyle: {
                color: '#fe6aa7'
            }
        },  {
            value: cancel,
            itemStyle: {
                color: '#e67400'
            }
        }],
        type: 'bar'
    }]
}
      // {
      //         title: {
      //                 text: "事项状态统计"
      //               },
      //               tooltip: {},
      //               legend: {
      //                 data: ["事项状态统计"]
                      
      //               },
      //               xAxis: {
      //                 data: ["督办总数", "督办承办", "督办销号", "督办延期", "督办取消"]
      //               },
      //               yAxis: {},
      //               series: [
      //                 {
      //                   color: '#22a2c3',
      //                   type: "bar",
      //                   data: [sum,todo,xiaohao,delay,cancel]
      //                 }
                    
      //               ]
      // }
      

          return newData;
};

 dianji= ()=>{
   this.initialize();
 }



  render() {

    const { option,series,date,flag } = this.state;
    const browserParams = { ...defaultBrowserParams };


    

    // debugger;
    return (
      <div style={{ height: 350 }}>
      <div id ="test">
      <span id = "bzsjid">布置时间:</span>
      <WeaRangePicker
          value={date}
          viewAttr={2}
          style={{width:300}}  
          onChange={value => {
            this.setState({date: value});
            this.initialize();
          }}
        />
        <span id = "cbbmid">承办部门:</span>
        <WeaBrowser
          style={{marginTop:10,marginBottom:10,marginLeft:10}}
          type={257}
          title="自定义树形多选"
          tabs={[
            {
              isSearch: false,
              key: "2",
              name: "组织结构",
              selected: false,
              showOrder: 0
            },
            {
              dataParams: { list: "1" },
              isSearch: true,
              key: "1",
              name: "按列表",
              selected: false,
              showOrder: 0
            }
          ]}
       onChange={(ids) => {
         this.setState({browserValue: ids});
        this.initialize()
       }
          }
          isSingle={false}
          dataParams={{ cube_treeid: "10001_searchType_searchType_searchType" }}
           destDataParams={{
            browsertype: "",
            cube_treeid: 10001,
            isshowsearchtab: 0,
            searchbrowserid: 0
          }}
          asynLoadAll={false}
          isLoadAll={false}
          defaultExpandedLevel={0}
          hasAdvanceSerach={false}
          //isMultCheckbox
          clickNameExpandFirst
          {...browserParams}
        />
    </div>
        <WeaEchart
          ref="chart"
          option={option}
          series={series}
          useDefault={false}
          style={{ height: 300 }}
        />
      </div>
    );
  }
}



//发布模块
ecodeSDK.setCom('${appId}','dubanbaobiao',dubanbaobiao);