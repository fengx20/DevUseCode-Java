"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaEchart = _ecCom.WeaEchart,
    WeaRangePicker = _ecCom.WeaRangePicker,
    WeaBrowser = _ecCom.WeaBrowser;
var defaultBrowserParams = {
  icon: "icon-toolbar-Organization-list",
  iconBgcolor: "#b32e37",
  inputStyle: {
    width: 250
  },
  maxBrowerHeight: 40,
  // ecId: "WeaBrowser@0t62u8",
  hasAdvanceSerach: true,
  pageSize: 30,
  selectedAllMaxLength: 500,
  displaySearchAdInBar: true,
  onBeforeFocusCheck: function onBeforeFocusCheck(success) {
    return success();
  },
  placeholder: "选择承办部门",
  title: '部门列表'
};

var dubanbaobiao =
/*#__PURE__*/
function (_React$Component) {
  _inherits(dubanbaobiao, _React$Component);

  function dubanbaobiao(props) {
    var _this;

    _classCallCheck(this, dubanbaobiao);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(dubanbaobiao).call(this, props));

    _this.initialize = function () {
      var that = _assertThisInitialized(_this);

      var _this$state = _this.state,
          browserValue = _this$state.browserValue,
          date = _this$state.date;
      setTimeout(function () {
        var startTime = $("input[placeholder$='开始日期']").attr("value");
        var endTime = $("input[placeholder$='结束日期']").attr("value");
        var cbbmdw = $("input[ecid$='undefined_WrappedComponent@i9q2c5_Component@iiw91q_input@jc79en']").attr("value");
        console.log(cbbmdw);
        console.log(startTime);
        console.log(endTime);
        var data = that.getdata(cbbmdw, startTime, endTime); // debugger;

        console.log(data); // this.setState({option:data,flag: true});

        that.setState({
          option: data
        });
        that.refs.chart.clear();
        that.forceUpdate();
        that.refs.chart.paint();
      }, 10);
    };

    _this.getdata = function (cbbmdw, startTime, endTime) {
      var sum = "0";
      var todo = "0";
      var xiaohao = "0";
      var delay = "0";
      var cancel = "0";
      jQuery.ajax({
        type: "GET",
        url: "/api/gtjt/OverseeReportAction/getDuBanJt",
        data: {
          "cbbmdw": cbbmdw,
          "startTime": startTime,
          "endTime": endTime
        },
        async: false,
        dataType: "json",
        success: function success(data) {
          sum = data.sumNum;
          todo = data.todoNum;
          xiaohao = data.xiaohaoNum;
          delay = data.delayNum;
          cancel = data.cancelNum;
        }
      }); //  console.log(sum);
      //  console.log(todo);
      //  console.log(xiaohao);
      //  console.log(delay);
      //  console.log(cancel);

      var newData = {
        xAxis: {
          type: 'category',
          data: ["督办总数", "督办承办", "督办销号", "督办延期", "督办取消"]
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          data: [{
            value: sum,
            itemStyle: {
              color: '#4a94ff'
            }
          }, {
            value: todo,
            itemStyle: {
              color: '#894ae9'
            }
          }, {
            value: xiaohao,
            itemStyle: {
              color: '#159dd1'
            }
          }, {
            value: delay,
            itemStyle: {
              color: '#fe6aa7'
            }
          }, {
            value: cancel,
            itemStyle: {
              color: '#e67400'
            }
          }],
          type: 'bar'
        }] // {
        //         title: {
        //                 text: "事项状态统计"
        //               },
        //               tooltip: {},
        //               legend: {
        //                 data: ["事项状态统计"]
        //               },
        //               xAxis: {
        //                 data: ["督办总数", "督办承办", "督办销号", "督办延期", "督办取消"]
        //               },
        //               yAxis: {},
        //               series: [
        //                 {
        //                   color: '#22a2c3',
        //                   type: "bar",
        //                   data: [sum,todo,xiaohao,delay,cancel]
        //                 }
        //               ]
        // }

      };
      return newData;
    };

    _this.dianji = function () {
      _this.initialize();
    };

    _this.state = {
      // sum :'0',
      // todo: '0',
      // xiaohao:'0',
      // delay:'0',
      // cancel:'0',
      date: "",
      browserValue: "",
      option: {} // flag: false

    };
    return _this;
  } //   // 初始化渲染页面


  _createClass(dubanbaobiao, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var data = this.getdata("", "", "");
      console.log(data); // debugger;

      this.setState({
        option: data
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$state2 = this.state,
          option = _this$state2.option,
          series = _this$state2.series,
          date = _this$state2.date,
          flag = _this$state2.flag;

      var browserParams = _objectSpread({}, defaultBrowserParams); // debugger;


      return React.createElement("div", {
        style: {
          height: 350
        }
      }, React.createElement("div", {
        id: "test"
      }, React.createElement("span", {
        id: "bzsjid"
      }, "\u5E03\u7F6E\u65F6\u95F4:"), React.createElement(WeaRangePicker, {
        value: date,
        viewAttr: 2,
        style: {
          width: 300
        },
        onChange: function onChange(value) {
          _this2.setState({
            date: value
          });

          _this2.initialize();
        }
      }), React.createElement("span", {
        id: "cbbmid"
      }, "\u627F\u529E\u90E8\u95E8:"), React.createElement(WeaBrowser, _extends({
        style: {
          marginTop: 10,
          marginBottom: 10,
          marginLeft: 10
        },
        type: 257,
        title: "\u81EA\u5B9A\u4E49\u6811\u5F62\u591A\u9009",
        tabs: [{
          isSearch: false,
          key: "2",
          name: "组织结构",
          selected: false,
          showOrder: 0
        }, {
          dataParams: {
            list: "1"
          },
          isSearch: true,
          key: "1",
          name: "按列表",
          selected: false,
          showOrder: 0
        }],
        onChange: function onChange(ids) {
          _this2.setState({
            browserValue: ids
          });

          _this2.initialize();
        },
        isSingle: false,
        dataParams: {
          cube_treeid: "10001_searchType_searchType_searchType"
        },
        destDataParams: {
          browsertype: "",
          cube_treeid: 10001,
          isshowsearchtab: 0,
          searchbrowserid: 0
        },
        asynLoadAll: false,
        isLoadAll: false,
        defaultExpandedLevel: 0,
        hasAdvanceSerach: false //isMultCheckbox
        ,
        clickNameExpandFirst: true
      }, browserParams))), React.createElement(WeaEchart, {
        ref: "chart",
        option: option,
        series: series,
        useDefault: false,
        style: {
          height: 300
        }
      }));
    }
  }]);

  return dubanbaobiao;
}(React.Component); //发布模块


ecodeSDK.setCom('${appId}', 'dubanbaobiao', dubanbaobiao);