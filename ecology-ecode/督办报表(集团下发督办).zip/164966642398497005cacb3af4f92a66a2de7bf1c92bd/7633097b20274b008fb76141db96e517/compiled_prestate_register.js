"use strict";

//注册和绑定新页面前端实现接口
ecodeSDK.rewriteRouteQueue.push({
  fn: function fn(params) {
    var Com = params.Com,
        Route = params.Route,
        nextState = params.nextState;
    var cpParams = {
      path: 'main/cs/app',
      //路由地址
      appId: '${appId}',
      name: 'dubanbaobiao',
      //具体页面应用id
      node: 'app',
      //渲染的路由节点，这里渲染的是app这个节点
      Route: Route,
      nextState: nextState
    };

    if (ecodeSDK.checkPath(cpParams)) {
      var acParams = {
        appId: cpParams.appId,
        name: cpParams.name,
        //模块名称
        props: params,
        //参数
        isPage: true,
        //是否是路由页面
        noCss: true //是否禁止单独加载css，通常为了减少css数量，css默认前置加载
        //异步加载模块${appId}下的子模块pageSimple

      };
      return ecodeSDK.getAsyncCom(acParams);
    }

    return null;
  },
  order: 10,
  desc: 'Demo简单页面'
});
/*
版本要求：kb1906以上
门户后台配置路由地址：
/spa/custom/static/index.html#main/cs/app/7633097b20274b008fb76141db96e517_dubanbaobiao
浏览器访问地址：
/wui/index.html#/main/cs/app/7633097b20274b008fb76141db96e517_dubanbaobiao
*/